<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Artikel terbaru dari zonakerja.id">
    <meta name="description" content="Temukan Artikel dan lowongan kerja terbaru dari zonakerja.id">
    <title>Lowongan Kerja Dari Rumah Terbaru 2023</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.15.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i">
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body data-home-page="Home.html" data-home-page-title="Home" class="u-body u-xl-mode" data-lang="en">
    <section class="u-clearfix u-valign-middle-xl u-section-1" id="carousel_63ba">
      <div class="u-clearfix u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-container-style u-layout-cell u-shape-rectangle u-size-20 u-layout-cell-1">
              <div class="u-container-layout u-valign-middle-lg u-valign-middle-md u-container-layout-1">
                <img class="u-expanded-width-lg u-expanded-width-md u-image u-image-default u-image-1" src="images/33809698_811830471.png" alt="" data-image-width="407" data-image-height="387">
              </div>
            </div>
            <div class="u-container-style u-layout-cell u-shape-rectangle u-size-40 u-layout-cell-2">
              <div class="u-container-layout u-valign-middle-xl u-valign-top-lg u-valign-top-md u-valign-top-sm u-valign-top-xs u-container-layout-2">
                <h1 class="u-custom-font u-font-ubuntu u-text u-text-default u-text-1">Artikel terbaru dari zonakerja.id</h1>
                <p class="u-text u-text-default u-text-2">
                  <a href="https://www.zonakerja.id/2023/08/7-website-membuat-cv-online-terbaik.html" class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-1" rel=”Dofollow”> 7 Website Membuat CV Online Terbaik</a>
                  <br>&nbsp;<a href="https://www.zonakerja.id/2023/08/8-poin-penting-dalam-membuat-cv-agar.html" class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-2" rel=”Dofollow”>8 Poin Penting Dalam Membuat CV Agar Dilirik HRD</a>
                  <br>&nbsp;<a href="https://www.zonakerja.id/2023/08/6-hal-penting-sebelum-melamar-pekerjaan.html" class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-3" rel=”Dofollow”>6 Hal Penting sebelum Melamar Pekerjaan</a>
                  <br>
                </p>
                <p class="u-text u-text-3">Info lowongan kerja <a href="https://www.zonakerja.id/" class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-4" rel=”Dofollow”>www.zonakerja.id</a>
                </p>
                <a href="https://www.zonakerja.id/" class="u-border-none u-btn u-btn-round u-button-style u-hover-palette-1-light-1 u-palette-3-base u-radius-50 u-btn-5" rel=”Dofollow”>Cari Lowongan Kerja</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-927e"><div class="u-clearfix u-sheet u-sheet-1"></div></footer>
  
</body></html>